import cv2
import torch
import os
import requests
import numpy as np

# Try to import YOLO and handle environment dependencies
try:
    from ultralytics import YOLO
    HAS_YOLO = True
except ImportError:
    HAS_YOLO = False
    print("Error: 'ultralytics' library not found. Please install it.")

class YoloDetector:
    def __init__(self, model_name='yolo11n.pt', device=None, conf_thres=0.5):
        """
        Initialize the YOLO detector
        :param model_name: Model name or path
        :param device: 'cpu' or 'cuda'
        :param conf_thres: Confidence threshold
        """
        self.conf_thres = conf_thres
        self.device = device if device else ('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Automatic download and loading logic
        self.model = self._load_model(model_name)
        print(f"[YoloDetector] Model loaded on {self.device}")

    def _load_model(self, model_name):
        """Load the model and try to download it if it is unavailable locally"""
        target_dir = './weights'
        if not os.path.exists(target_dir):
            os.makedirs(target_dir)
        
        if not model_name.endswith('.pt'):
            model_name += '.pt'
        
        model_path = os.path.join(target_dir, model_name)
        
        if HAS_YOLO:
            return YOLO(model_path) 
        return None

    def detect(self, cv_image, classes=None):
        """
        Run detection
        :param cv_image: OpenCV BGR image
        :param classes: (List[int]) Specify class IDs to detect; for example, [0] is person and [47] is apple. None detects all classes。
        :return: list of dicts [{'box': [x1,y1,x2,y2], 'conf': float, 'cls': int}, ...]
        """
        if self.model is None:
            return []

        # verbose=False Disable console output
        results = self.model(cv_image, classes=classes, conf=self.conf_thres, device=self.device, verbose=False)
        
        detections = []
        for r in results:
            boxes = r.boxes
            for box in boxes:
                # Get integer coordinates (int)
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls_id = int(box.cls[0])
                
                detections.append({
                    'box': [x1, y1, x2, y2],
                    'conf': conf,
                    'cls': cls_id,
                    'label': self.model.names[cls_id] # Useful for debugging to see what was detected
                })
        
        return detections
