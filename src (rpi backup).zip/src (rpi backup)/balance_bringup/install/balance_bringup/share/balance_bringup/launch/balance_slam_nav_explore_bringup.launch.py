#!/usr/bin/env python3

import os
import sys

from ament_index_python.packages import (
    get_package_share_directory,
)

from launch import LaunchDescription
from launch.actions import (
    ExecuteProcess,
    IncludeLaunchDescription,
    LogInfo,
    TimerAction,
)
from launch.launch_description_sources import (
    PythonLaunchDescriptionSource,
)


def generate_launch_description():
    """
    Startup sequence:

    1. Start robot base immediately.
    2. Start LiDAR after 2 seconds.
    3. Start scan_resampler.py after 4 seconds.
    4. Start SLAM Toolbox after 7 seconds.
    5. Start Nav2 core after 11 seconds.
    6. Start explore_lite after 16 seconds.
    """

    # =========================================================
    # Locate all launch files
    # =========================================================

    robot_base_launch_file = os.path.join(
        get_package_share_directory(
            'balance_robot_base'
        ),
        'launch',
        'balance_robot_base.launch.py',
    )

    lidar_launch_file = os.path.join(
        get_package_share_directory(
            'lslidar_driver_n10p'
        ),
        'launch',
        'lslidar_launch.py',
    )

    slam_launch_file = os.path.join(
        get_package_share_directory(
            'balance_mapping'
        ),
        'launch',
        'balance_mapping_slamtoolbox_async.launch.py',
    )

    nav2_launch_file = os.path.join(
        get_package_share_directory(
            'balance_navigation'
        ),
        'launch',
        'balance_nav2_core.launch.py',
    )

    explorer_launch_file = os.path.join(
        get_package_share_directory(
            'balance_mapping'
        ),
        'launch',
        'balance_explorer_lite.launch.py',
    )

    # Standalone scan-resampler script
    scan_resampler_file = (
        '/home/ros2_ws/scan_resampler.py'
    )

    # =========================================================
    # 0 seconds: robot base
    # =========================================================

    robot_base_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            robot_base_launch_file
        )
    )

    # =========================================================
    # 2 seconds: LiDAR
    # =========================================================

    lidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            lidar_launch_file
        )
    )

    delayed_lidar_launch = TimerAction(
        period=2.0,
        actions=[
            LogInfo(
                msg='[bringup] Starting LiDAR...'
            ),
            lidar_launch,
        ],
    )

    # =========================================================
    # 4 seconds: scan resampler
    #
    # Converts:
    #   /scan -> /scan_fixed
    # =========================================================

    scan_resampler_process = ExecuteProcess(
        cmd=[
            sys.executable,
            scan_resampler_file,
            '--ros-args',
            '-p',
            'input_topic:=/scan',
            '-p',
            'output_topic:=/scan_fixed',
            '-p',
            'number_of_bins:=450',
        ],
        name='scan_resampler_process',
        output='screen',
    )

    delayed_scan_resampler = TimerAction(
        period=4.0,
        actions=[
            LogInfo(
                msg='[bringup] Starting scan resampler...'
            ),
            scan_resampler_process,
        ],
    )

    # =========================================================
    # 7 seconds: SLAM Toolbox
    #
    # SLAM Toolbox should subscribe to /scan_fixed.
    # =========================================================

    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            slam_launch_file
        )
    )

    delayed_slam_launch = TimerAction(
        period=7.0,
        actions=[
            LogInfo(
                msg='[bringup] Starting SLAM Toolbox...'
            ),
            slam_launch,
        ],
    )

    # =========================================================
    # 11 seconds: Nav2 core
    # =========================================================

    nav2_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            nav2_launch_file
        )
    )

    delayed_nav2_launch = TimerAction(
        period=11.0,
        actions=[
            LogInfo(
                msg='[bringup] Starting Nav2 core...'
            ),
            nav2_launch,
        ],
    )

    # =========================================================
    # 16 seconds: automatic exploration
    # =========================================================

    explorer_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            explorer_launch_file
        )
    )

    delayed_explorer_launch = TimerAction(
        period=16.0,
        actions=[
            LogInfo(
                msg='[bringup] Starting explore_lite...'
            ),
            explorer_launch,
        ],
    )

    # =========================================================
    # Complete launch description
    # =========================================================

    return LaunchDescription([
        robot_base_launch,
        delayed_lidar_launch,
        delayed_scan_resampler,
        delayed_slam_launch,
        delayed_nav2_launch,
        delayed_explorer_launch,
    ])
